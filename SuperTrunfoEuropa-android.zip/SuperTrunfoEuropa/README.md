# Super Trunfo Europa (APK)

O app é um WebView que abre o jogo (app/src/main/assets/index.html).
Para mudar o jogo, edite esse arquivo e gere o APK de novo.

## Gerar o APK pelo GitHub (grátis)
1. Crie um repositório no GitHub e envie TODOS os arquivos desta pasta (inclusive a pasta oculta .github).
2. Aba "Actions" > "Build APK" > "Run workflow" (ou ele roda sozinho a cada envio).
3. Quando terminar (uns 3-5 min), abra a execução e baixe o arquivo "SuperTrunfoEuropa-apk".
4. Descompacte, mande o app-debug.apk para os celulares e instale (permita "fontes desconhecidas").

## Gerar pelo Android Studio
Abra esta pasta, espere o sync e use Build > Build APK(s).
O arquivo sai em app/build/outputs/apk/debug/app-debug.apk.
